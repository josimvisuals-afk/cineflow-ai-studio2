# Remotion Video Engine

This directory is reserved for the **2.5D Remotion documentary renderer**, which will be built in **Step 5**.

It will turn approved storyboards into rendered documentary video (parallax image layers, camera moves, narration sync, captions).

Nothing to run here yet.
