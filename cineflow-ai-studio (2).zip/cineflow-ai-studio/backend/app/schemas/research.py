import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ResearchRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    project_id: uuid.UUID
    summary: str
    key_facts: list[str]
    historical_context: str
    visual_angles: list[str]
    created_at: datetime
    updated_at: datetime
