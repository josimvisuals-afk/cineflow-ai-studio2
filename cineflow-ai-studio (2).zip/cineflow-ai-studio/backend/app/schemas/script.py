import uuid
from datetime import datetime

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class ScriptRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    project_id: uuid.UUID
    title: str
    narration_text: str
    word_count: int
    estimated_duration_seconds: int
    status: str
    created_at: datetime
    updated_at: datetime


class ScriptUpdate(BaseModel):
    title: str | None = Field(default=None, max_length=200)
    narration_text: str | None = None

    @field_validator("title", "narration_text")
    @classmethod
    def not_blank(cls, v: str | None) -> str | None:
        if v is None:
            return v
        v = v.strip()
        if not v:
            raise ValueError("must not be blank")
        return v

    @model_validator(mode="after")
    def at_least_one_field(self) -> "ScriptUpdate":
        if self.title is None and self.narration_text is None:
            raise ValueError("Provide title and/or narration_text")
        return self
