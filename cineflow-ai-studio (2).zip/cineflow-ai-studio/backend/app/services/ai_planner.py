"""Claude-powered research and script generation.

Everything here calls the real Anthropic API. If the key is missing or the API
fails, an AIServiceError is raised with a clear message. No fallback or fake
content is ever returned.
"""

import logging
from typing import Any

import anthropic
from pydantic import BaseModel, ValidationError, field_validator

from app.core.config import settings

logger = logging.getLogger("cineflow.ai")

# Calm documentary narration pace.
WORDS_PER_MINUTE = 140
MIN_WPM = 130
MAX_WPM = 150


class AIServiceError(Exception):
    """An AI call could not be completed. Carries the HTTP status to return."""

    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


# --------------------------------------------------------------------------- #
# Word / duration helpers (shared with the PATCH route)
# --------------------------------------------------------------------------- #
def count_words(text: str) -> int:
    return len(text.split())


def estimate_duration_seconds(word_count: int) -> int:
    return round(word_count / WORDS_PER_MINUTE * 60)


# --------------------------------------------------------------------------- #
# Structured results
# --------------------------------------------------------------------------- #
def _clean_list(items: list[str]) -> list[str]:
    return [i.strip() for i in items if i and i.strip()]


class ResearchResult(BaseModel):
    summary: str
    key_facts: list[str]
    historical_context: str
    visual_angles: list[str]

    @field_validator("key_facts", "visual_angles")
    @classmethod
    def non_empty_list(cls, v: list[str]) -> list[str]:
        cleaned = _clean_list(v)
        if not cleaned:
            raise ValueError("list must not be empty")
        return cleaned

    @field_validator("summary", "historical_context")
    @classmethod
    def non_blank(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("must not be blank")
        return v


class ScriptResult(BaseModel):
    title: str
    narration_text: str

    @field_validator("title", "narration_text")
    @classmethod
    def non_blank(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("must not be blank")
        return v


# --------------------------------------------------------------------------- #
# Anthropic plumbing
# --------------------------------------------------------------------------- #
def _client() -> anthropic.Anthropic:
    key = settings.ANTHROPIC_API_KEY.strip()
    if not key:
        raise AIServiceError(
            503,
            "ANTHROPIC_API_KEY is not set. Add it to your .env file and restart the backend.",
        )
    return anthropic.Anthropic(api_key=key, timeout=300.0, max_retries=2)


def _call_tool(
    *,
    system: str,
    user: str,
    tool_name: str,
    tool_description: str,
    schema: dict[str, Any],
    max_tokens: int,
) -> dict[str, Any]:
    """Call Claude, forcing a single tool call so the output is structured JSON."""
    client = _client()
    try:
        response = client.messages.create(
            model=settings.CLAUDE_MODEL,
            max_tokens=max_tokens,
            system=system,
            tools=[
                {
                    "name": tool_name,
                    "description": tool_description,
                    "input_schema": schema,
                }
            ],
            tool_choice={"type": "tool", "name": tool_name},
            messages=[{"role": "user", "content": user}],
        )
    except anthropic.AuthenticationError:
        raise AIServiceError(
            503,
            "Anthropic rejected ANTHROPIC_API_KEY (invalid or revoked). "
            "Check the key in your .env file and restart the backend.",
        ) from None
    except anthropic.PermissionDeniedError:
        raise AIServiceError(
            503, "Your Anthropic API key does not have permission to use this model."
        ) from None
    except anthropic.NotFoundError:
        raise AIServiceError(
            503,
            f"Anthropic model '{settings.CLAUDE_MODEL}' was not found. "
            "Check CLAUDE_MODEL in your .env file.",
        ) from None
    except anthropic.RateLimitError:
        raise AIServiceError(
            429, "Anthropic rate limit reached. Wait a minute and try again."
        ) from None
    except anthropic.APITimeoutError:
        raise AIServiceError(
            503, "The request to Anthropic timed out. Try again in a moment."
        ) from None
    except anthropic.APIConnectionError:
        raise AIServiceError(
            503, "Could not connect to the Anthropic API. Check your internet connection."
        ) from None
    except anthropic.APIStatusError as e:
        logger.warning("Anthropic API error %s: %s", e.status_code, e.message)
        raise AIServiceError(
            502, f"Anthropic API error ({e.status_code}): {e.message}"
        ) from None
    except anthropic.APIError as e:
        raise AIServiceError(502, f"Anthropic API error: {e}") from None

    if response.stop_reason == "max_tokens":
        raise AIServiceError(
            502,
            "The AI response was cut off before it finished. "
            "Try again, or choose a shorter target duration.",
        )

    for block in response.content:
        if block.type == "tool_use" and block.name == tool_name:
            return dict(block.input)

    raise AIServiceError(502, "The AI response did not contain the expected structured output.")


# --------------------------------------------------------------------------- #
# Research
# --------------------------------------------------------------------------- #
RESEARCH_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "summary": {
            "type": "string",
            "description": "Two to three paragraphs summarising the subject and the strongest story angle.",
        },
        "key_facts": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Distinct, specific facts, each one or two sentences.",
        },
        "historical_context": {
            "type": "string",
            "description": "Two to four paragraphs of background, separated by blank lines.",
        },
        "visual_angles": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Concrete visual ideas, each described in one sentence.",
        },
    },
    "required": ["summary", "key_facts", "historical_context", "visual_angles"],
}

RESEARCH_SYSTEM = (
    "You are a senior documentary researcher preparing a briefing for a "
    "narrator-driven documentary. You have no web access, so you work only from "
    "your own knowledge. Accuracy matters more than volume: never invent quotes, "
    "statistics, dates, names or sources. When something is uncertain or disputed, "
    "say so inside the fact itself. Prefer concrete, specific, checkable details "
    "over generalities. Write in clear, plain English."
)


def generate_research(
    *, title: str, topic: str, target_duration_seconds: int
) -> ResearchResult:
    minutes = target_duration_seconds / 60
    n_facts = max(6, min(20, round(6 + minutes * 2)))
    user = (
        f"Project title: {title}\n"
        f"Topic: {topic}\n"
        f"Target film length: {target_duration_seconds} seconds (about {minutes:.1f} minutes)\n\n"
        "Prepare research notes for this film by calling the save_research tool.\n"
        "- summary: two to three paragraphs on the subject and the most compelling story angle.\n"
        f"- key_facts: about {n_facts} distinct, specific facts, ordered roughly in the order "
        "a story would use them.\n"
        "- historical_context: two to four paragraphs on causes, people, setting, consequences "
        "and why the subject still matters. Separate paragraphs with a blank line.\n"
        "- visual_angles: six to ten concrete things a storyboard artist could show on screen "
        "(places, objects, maps, archival-style imagery, reconstructions, motion graphics), "
        "each described in one sentence.\n"
        "Size the depth of the notes to the film length."
    )
    raw = _call_tool(
        system=RESEARCH_SYSTEM,
        user=user,
        tool_name="save_research",
        tool_description="Save the structured research notes for the documentary.",
        schema=RESEARCH_SCHEMA,
        max_tokens=4096,
    )
    try:
        return ResearchResult.model_validate(raw)
    except ValidationError as e:
        logger.warning("Malformed research output: %s", e)
        raise AIServiceError(
            502, "The AI returned research notes in an unexpected format. Please try again."
        ) from None


# --------------------------------------------------------------------------- #
# Script
# --------------------------------------------------------------------------- #
SCRIPT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {
            "type": "string",
            "description": "An evocative title for the film, under 80 characters.",
        },
        "narration_text": {
            "type": "string",
            "description": (
                "The complete voice-over narration as plain prose paragraphs separated "
                "by blank lines. No headings, markdown, timecodes or stage directions."
            ),
        },
    },
    "required": ["title", "narration_text"],
}

SCRIPT_SYSTEM = (
    "You are an award-winning narrative documentary writer. You write voice-over "
    "narration for a performer reading at a calm, measured documentary pace. Your "
    "craft: open with a moment that earns attention, build the story through concrete "
    "images and human-scale details rather than abstractions, let each paragraph turn "
    "the story forward, and end on a line that lingers. Vary sentence length, keep "
    "sentences speakable, and avoid cliches and filler. You only use facts from the "
    "research notes or knowledge you are highly confident in. Never invent quotes, "
    "statistics or named sources; hedge anything uncertain."
)


def _structure_hint(target_duration_seconds: int) -> str:
    if target_duration_seconds <= 90:
        return (
            "a single tight arc: a one-sentence hook, the core of the story, "
            "and a closing line that lingers"
        )
    if target_duration_seconds <= 300:
        return (
            "a hook, three short movements (setup, turn, consequence), "
            "and a closing reflection"
        )
    return (
        "a cold open, then clearly shaped acts with rising stakes and a turning point, "
        "and a closing reflection that echoes the opening image"
    )


def _research_block(
    *,
    summary: str,
    key_facts: list[str],
    historical_context: str,
    visual_angles: list[str],
) -> str:
    facts = "\n".join(f"- {f}" for f in key_facts)
    angles = "\n".join(f"- {a}" for a in visual_angles)
    return (
        f"SUMMARY\n{summary}\n\n"
        f"KEY FACTS\n{facts}\n\n"
        f"HISTORICAL CONTEXT\n{historical_context}\n\n"
        f"VISUAL ANGLES (for tone only; do not describe visuals in the narration)\n{angles}"
    )


def generate_script(
    *,
    title: str,
    topic: str,
    target_duration_seconds: int,
    summary: str,
    key_facts: list[str],
    historical_context: str,
    visual_angles: list[str],
) -> ScriptResult:
    minutes = target_duration_seconds / 60
    target_words = round(minutes * WORDS_PER_MINUTE)
    min_words = round(minutes * MIN_WPM)
    max_words = round(minutes * MAX_WPM)
    notes = _research_block(
        summary=summary,
        key_facts=key_facts,
        historical_context=historical_context,
        visual_angles=visual_angles,
    )
    user = (
        f"Project title: {title}\n"
        f"Topic: {topic}\n"
        f"Target film length: {target_duration_seconds} seconds (about {minutes:.1f} minutes)\n\n"
        f"RESEARCH NOTES\n{notes}\n\n"
        "Write the narration by calling the save_script tool.\n"
        f"- Length: about {target_words} words (acceptable range {min_words} to {max_words}), "
        f"which fills the runtime at {MIN_WPM} to {MAX_WPM} words per minute. "
        "Count carefully; do not run short.\n"
        f"- Shape: {_structure_hint(target_duration_seconds)}.\n"
        "- Spoken words only: no headings, markdown, bullet points, brackets, camera or "
        "music directions, timecodes or speaker labels.\n"
        "- Write numbers and abbreviations the way a narrator would say them.\n"
        "- Separate paragraphs with a blank line."
    )
    max_tokens = min(16000, max(2048, target_words * 2 + 1024))
    raw = _call_tool(
        system=SCRIPT_SYSTEM,
        user=user,
        tool_name="save_script",
        tool_description="Save the documentary title and narration script.",
        schema=SCRIPT_SCHEMA,
        max_tokens=max_tokens,
    )
    try:
        return ScriptResult.model_validate(raw)
    except ValidationError as e:
        logger.warning("Malformed script output: %s", e)
        raise AIServiceError(
            502, "The AI returned a script in an unexpected format. Please try again."
        ) from None
