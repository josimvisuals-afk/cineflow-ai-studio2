import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.project import Project, ProjectStatus
from app.models.research_note import ResearchNote
from app.models.script import Script
from app.schemas.research import ResearchRead
from app.schemas.script import ScriptRead, ScriptUpdate
from app.services import ai_planner

router = APIRouter(prefix="/api")


def _project_or_404(db: Session, project_id: uuid.UUID) -> Project:
    project = db.get(Project, project_id)
    if project is None:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


def _research_for(db: Session, project_id: uuid.UUID) -> ResearchNote | None:
    return db.scalar(select(ResearchNote).where(ResearchNote.project_id == project_id))


def _script_for(db: Session, project_id: uuid.UUID) -> Script | None:
    return db.scalar(select(Script).where(Script.project_id == project_id))


def _advance_status(project: Project, target: ProjectStatus, *, only_from: set[ProjectStatus]):
    """Move the project forward in the pipeline, never backwards."""
    if project.status in only_from:
        project.status = target


# ----------------------------- Research ----------------------------------- #
@router.post("/projects/{project_id}/research", response_model=ResearchRead)
def generate_research(project_id: uuid.UUID, db: Session = Depends(get_db)):
    project = _project_or_404(db, project_id)
    title, topic, duration = project.title, project.topic, project.target_duration_seconds

    # Raises AIServiceError (handled in main.py) if the key is missing or the API fails.
    result = ai_planner.generate_research(
        title=title, topic=topic, target_duration_seconds=duration
    )

    note = _research_for(db, project.id)
    if note is None:
        note = ResearchNote(project_id=project.id)
        db.add(note)
    note.summary = result.summary
    note.key_facts = result.key_facts
    note.historical_context = result.historical_context
    note.visual_angles = result.visual_angles

    _advance_status(project, ProjectStatus.researching, only_from={ProjectStatus.draft})
    db.commit()
    db.refresh(note)
    return note


@router.get("/projects/{project_id}/research", response_model=ResearchRead)
def get_research(project_id: uuid.UUID, db: Session = Depends(get_db)):
    _project_or_404(db, project_id)
    note = _research_for(db, project_id)
    if note is None:
        raise HTTPException(status_code=404, detail="No research notes yet for this project")
    return note


# ------------------------------- Script ----------------------------------- #
@router.post("/projects/{project_id}/script", response_model=ScriptRead)
def generate_script(project_id: uuid.UUID, db: Session = Depends(get_db)):
    project = _project_or_404(db, project_id)
    note = _research_for(db, project.id)
    if note is None:
        raise HTTPException(
            status_code=409,
            detail="Generate research notes first. The script is written from them.",
        )

    result = ai_planner.generate_script(
        title=project.title,
        topic=project.topic,
        target_duration_seconds=project.target_duration_seconds,
        summary=note.summary,
        key_facts=list(note.key_facts),
        historical_context=note.historical_context,
        visual_angles=list(note.visual_angles),
    )

    words = ai_planner.count_words(result.narration_text)
    script = _script_for(db, project.id)
    if script is None:
        script = Script(project_id=project.id)
        db.add(script)
    script.title = result.title[:200]
    script.narration_text = result.narration_text
    script.word_count = words
    script.estimated_duration_seconds = ai_planner.estimate_duration_seconds(words)
    script.status = "draft"

    _advance_status(
        project,
        ProjectStatus.scripting,
        only_from={ProjectStatus.draft, ProjectStatus.researching},
    )
    db.commit()
    db.refresh(script)
    return script


@router.get("/projects/{project_id}/script", response_model=ScriptRead)
def get_script(project_id: uuid.UUID, db: Session = Depends(get_db)):
    _project_or_404(db, project_id)
    script = _script_for(db, project_id)
    if script is None:
        raise HTTPException(status_code=404, detail="No script yet for this project")
    return script


@router.patch("/projects/{project_id}/script", response_model=ScriptRead)
def update_script(
    project_id: uuid.UUID, payload: ScriptUpdate, db: Session = Depends(get_db)
):
    _project_or_404(db, project_id)
    script = _script_for(db, project_id)
    if script is None:
        raise HTTPException(status_code=404, detail="No script yet for this project")

    if payload.title is not None:
        script.title = payload.title
    if payload.narration_text is not None:
        script.narration_text = payload.narration_text
    words = ai_planner.count_words(script.narration_text)
    script.word_count = words
    script.estimated_duration_seconds = ai_planner.estimate_duration_seconds(words)

    db.commit()
    db.refresh(script)
    return script
