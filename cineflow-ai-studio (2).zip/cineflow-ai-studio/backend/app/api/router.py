from fastapi import APIRouter

from app.api.routes import projects, research_script

api_router = APIRouter()
api_router.include_router(projects.router)
api_router.include_router(research_script.router)
