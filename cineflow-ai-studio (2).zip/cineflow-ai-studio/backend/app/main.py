import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app import models  # noqa: F401  (registers models on Base.metadata)
from app.api.router import api_router
from app.core.config import settings
from app.db.base import Base
from app.db.session import engine
from app.services.ai_planner import AIServiceError

logger = logging.getLogger("cineflow")


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Creates any missing tables (new Step 2 tables included). Alembic can take over later.
    try:
        Base.metadata.create_all(bind=engine)
    except Exception:  # keep the API up so /api/health can report the DB problem
        logger.exception("Could not create tables. Is PostgreSQL running?")
    yield


app = FastAPI(title="CineFlow AI Studio API", version="0.2.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(AIServiceError)
async def ai_service_error_handler(_: Request, exc: AIServiceError):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


app.include_router(api_router)
