import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#1b1917", // charcoal page background
        panel: "#25221f", // raised surfaces
        rule: "#3a352f", // borders and dividers
        paper: "#eae1d3", // primary text (warm off-white)
        dim: "#9a8f82", // secondary text
        lamp: "#e9a23b", // amber: primary accent
        ember: "#c4571c", // burnt orange: secondary accent
      },
      fontFamily: {
        serif: ["var(--font-serif)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
