"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import ErrorBanner from "@/components/ErrorBanner";
import ResearchSection from "@/components/ResearchSection";
import ScriptEditor from "@/components/ScriptEditor";
import StatusBadge from "@/components/StatusBadge";
import {
  ApiError,
  getProject,
  getResearch,
  getScript,
  type Project,
  type ResearchNote,
  type Script,
} from "@/lib/api";
import { formatDuration } from "@/lib/format";

type LoadError = "not-found" | "unreachable" | null;

function BackLink() {
  return (
    <Link
      href="/"
      className="inline-flex items-center gap-1.5 text-sm text-dim hover:text-paper"
    >
      <svg
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="M10 3 5 8l5 5" />
      </svg>
      Back to dashboard
    </Link>
  );
}

export default function ProjectStudio({ projectId }: { projectId: string }) {
  const [project, setProject] = useState<Project | null>(null);
  const [research, setResearch] = useState<ResearchNote | null>(null);
  const [script, setScript] = useState<Script | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<LoadError>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [p, r, s] = await Promise.all([
          getProject(projectId),
          getResearch(projectId),
          getScript(projectId),
        ]);
        if (cancelled) return;
        setProject(p);
        setResearch(r);
        setScript(s);
      } catch (e) {
        if (cancelled) return;
        const missing = e instanceof ApiError && (e.status === 404 || e.status === 422);
        setLoadError(missing ? "not-found" : "unreachable");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [projectId]);

  // Generating research or a script can advance the project status, so refresh it.
  const refreshProject = useCallback(async () => {
    try {
      setProject(await getProject(projectId));
    } catch {
      // keep showing the last known project
    }
  }, [projectId]);

  if (loading) {
    return (
      <div aria-hidden="true" className="space-y-4">
        <div className="h-8 w-1/2 rounded bg-panel motion-safe:animate-pulse" />
        <div className="h-24 rounded bg-panel motion-safe:animate-pulse" />
      </div>
    );
  }

  if (loadError === "not-found") {
    return (
      <div className="space-y-4">
        <BackLink />
        <div className="rounded-md border border-dashed border-rule px-6 py-16 text-center">
          <p className="font-serif text-xl">Project not found</p>
          <p className="mt-2 text-dim">
            It may have been deleted. Go back to the dashboard to pick another.
          </p>
        </div>
      </div>
    );
  }

  if (loadError === "unreachable" || !project) {
    return (
      <div className="space-y-4">
        <BackLink />
        <ErrorBanner message="Can't load this project. Start the backend and check that PostgreSQL is running, then reload the page." />
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <header className="space-y-4">
        <BackLink />
        <div className="flex flex-wrap items-start justify-between gap-3">
          <h1 className="font-serif text-4xl font-semibold tracking-tight">
            {project.title}
          </h1>
          <StatusBadge status={project.status} />
        </div>
        <p className="max-w-3xl leading-relaxed text-paper/90">{project.topic}</p>
        <p className="text-sm text-dim">
          Target runtime {formatDuration(project.target_duration_seconds)} min
        </p>
      </header>

      <ResearchSection
        projectId={project.id}
        research={research}
        onGenerated={(note) => {
          setResearch(note);
          refreshProject();
        }}
      />

      <ScriptEditor
        projectId={project.id}
        script={script}
        hasResearch={research !== null}
        targetSeconds={project.target_duration_seconds}
        onChanged={(next) => {
          setScript(next);
          refreshProject();
        }}
      />
    </div>
  );
}
