import HealthIndicator from "@/components/HealthIndicator";

export default function Header() {
  return (
    <header className="border-b border-rule">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-5 py-5 sm:px-8">
        <h1 className="font-serif text-2xl font-semibold tracking-tight text-paper sm:text-3xl">
          CineFlow AI Studio
        </h1>
        <HealthIndicator />
      </div>
    </header>
  );
}
