"use client";

import { useEffect, useState } from "react";
import ErrorBanner from "@/components/ErrorBanner";
import { generateScript, updateScript, type Script } from "@/lib/api";
import {
  countWords,
  estimateSeconds,
  formatDuration,
  WORDS_PER_MINUTE,
} from "@/lib/format";

export default function ScriptEditor({
  projectId,
  script,
  hasResearch,
  targetSeconds,
  onChanged,
}: {
  projectId: string;
  script: Script | null;
  hasResearch: boolean;
  targetSeconds: number;
  onChanged: (script: Script) => void;
}) {
  const [title, setTitle] = useState(script?.title ?? "");
  const [narration, setNarration] = useState(script?.narration_text ?? "");
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Reset the editor whenever a new version of the script arrives from the server.
  useEffect(() => {
    setTitle(script?.title ?? "");
    setNarration(script?.narration_text ?? "");
  }, [script]);

  const words = countWords(narration);
  const seconds = estimateSeconds(words);
  const ratio = targetSeconds > 0 ? seconds / targetSeconds : 0;
  const onTarget = ratio >= 0.85 && ratio <= 1.15;
  const dirty =
    script !== null &&
    (title !== script.title || narration !== script.narration_text);
  const canSave = dirty && title.trim() !== "" && narration.trim() !== "" && !saving;

  async function runGenerate() {
    setConfirming(false);
    setGenerating(true);
    setError(null);
    setSaved(false);
    try {
      onChanged(await generateScript(projectId));
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Could not generate the script. Check that the backend is running.",
      );
    } finally {
      setGenerating(false);
    }
  }

  async function handleSave() {
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      onChanged(
        await updateScript(projectId, {
          title: title.trim(),
          narration_text: narration,
        }),
      );
      setSaved(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save your changes.");
    } finally {
      setSaving(false);
    }
  }

  const barWidth = `${Math.min(100, Math.round(ratio * 100))}%`;
  const fieldClass =
    "w-full rounded-md border border-rule bg-ink px-3 py-2 text-paper placeholder:text-dim/70 focus:border-lamp focus:outline-none";

  return (
    <section aria-labelledby="script-heading" className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 id="script-heading" className="font-serif text-2xl font-semibold">
            Script
          </h2>
          <p className="mt-1 text-sm text-dim">
            {hasResearch
              ? "Narration written from your research notes."
              : "Generate research first. The script is written from those notes."}
          </p>
        </div>

        {confirming ? (
          <div className="flex flex-wrap items-center gap-3">
            <p className="text-sm text-dim">
              This replaces the current script, including unsaved edits.
            </p>
            <button
              type="button"
              onClick={runGenerate}
              className="rounded-md bg-ember px-4 py-2 text-sm font-semibold text-paper hover:brightness-110"
            >
              Replace script
            </button>
            <button
              type="button"
              onClick={() => setConfirming(false)}
              className="rounded-md px-3 py-2 text-sm font-medium text-dim hover:text-paper"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => (script ? setConfirming(true) : runGenerate())}
            disabled={!hasResearch || generating}
            className="rounded-md bg-lamp px-5 py-2.5 text-sm font-semibold text-ink hover:brightness-110 disabled:opacity-50"
          >
            {generating
              ? "Writing script"
              : script
                ? "Regenerate Script"
                : "Generate Script"}
          </button>
        )}
      </div>

      {generating && (
        <p role="status" className="text-sm text-dim">
          Claude is writing the narration. Longer films can take a few minutes.
        </p>
      )}

      {error && <ErrorBanner message={error} onDismiss={() => setError(null)} />}

      {!script && !generating && (
        <div className="rounded-md border border-dashed border-rule px-6 py-12 text-center">
          <p className="font-serif text-xl">No script yet</p>
          <p className="mx-auto mt-2 max-w-md text-dim">
            {hasResearch
              ? "Generate a script sized to your target runtime, then edit it here."
              : "Once research exists, you can generate a script sized to your target runtime."}
          </p>
        </div>
      )}

      {script && (
        <div className="space-y-5 rounded-md border border-rule bg-panel p-6">
          <div className="space-y-1.5">
            <label htmlFor="script-title" className="text-sm font-medium">
              Script title
            </label>
            <input
              id="script-title"
              value={title}
              maxLength={200}
              onChange={(e) => {
                setTitle(e.target.value);
                setSaved(false);
              }}
              className={`${fieldClass} font-serif text-lg`}
            />
          </div>

          <div className="space-y-1.5">
            <label htmlFor="script-narration" className="text-sm font-medium">
              Narration
            </label>
            <textarea
              id="script-narration"
              value={narration}
              onChange={(e) => {
                setNarration(e.target.value);
                setSaved(false);
              }}
              rows={18}
              className={`${fieldClass} min-h-[24rem] resize-y font-serif text-lg leading-8`}
            />
          </div>

          <div className="space-y-2" aria-live="polite">
            <div className="flex flex-wrap items-baseline gap-x-6 gap-y-1 text-sm">
              <p>
                <span className="font-semibold text-paper">{words}</span>{" "}
                <span className="text-dim">words</span>
              </p>
              <p>
                <span className="font-semibold text-paper">
                  {formatDuration(seconds)}
                </span>{" "}
                <span className="text-dim">
                  estimated at {WORDS_PER_MINUTE} words a minute
                </span>
              </p>
              <p className="text-dim">
                Target {formatDuration(targetSeconds)}
                {words > 0 &&
                  (onTarget
                    ? ", on target"
                    : seconds < targetSeconds
                      ? ", running short"
                      : ", running long")}
              </p>
            </div>
            <div
              className="h-1.5 w-full overflow-hidden rounded-full bg-rule"
              role="img"
              aria-label={`Script length is ${Math.round(ratio * 100)} percent of the target duration`}
            >
              <div
                className={`h-full rounded-full ${onTarget ? "bg-lamp" : "bg-ember"}`}
                style={{ width: barWidth }}
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-4">
            {saved && !dirty && (
              <p role="status" className="text-sm text-[#a8cc8c]">
                Changes saved
              </p>
            )}
            <button
              type="button"
              onClick={handleSave}
              disabled={!canSave}
              className="rounded-md bg-lamp px-5 py-2.5 text-sm font-semibold text-ink hover:brightness-110 disabled:opacity-50"
            >
              {saving ? "Saving changes" : "Save Changes"}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
