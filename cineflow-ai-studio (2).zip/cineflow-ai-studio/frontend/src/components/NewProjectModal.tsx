"use client";

import { useEffect, useId, useState } from "react";
import { createProject, type Project } from "@/lib/api";
import { formatDuration } from "@/lib/format";

const MIN_SECONDS = 5;
const MAX_SECONDS = 3600;

export default function NewProjectModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (project: Project) => void;
}) {
  const titleId = useId();
  const [title, setTitle] = useState("");
  const [topic, setTopic] = useState("");
  const [duration, setDuration] = useState("60");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !submitting) onClose();
    };
    document.addEventListener("keydown", onKey);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [onClose, submitting]);

  const seconds = Number(duration);
  const durationValid =
    Number.isInteger(seconds) && seconds >= MIN_SECONDS && seconds <= MAX_SECONDS;

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!durationValid) {
      setError(
        `Target duration must be a whole number between ${MIN_SECONDS} and ${MAX_SECONDS} seconds.`,
      );
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const project = await createProject({
        title: title.trim(),
        topic: topic.trim(),
        target_duration_seconds: seconds,
      });
      onCreated(project);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Could not create the project. Check that the backend is running.",
      );
      setSubmitting(false);
    }
  }

  const fieldClass =
    "w-full rounded-md border border-rule bg-ink px-3 py-2 text-paper placeholder:text-dim/70 focus:border-lamp focus:outline-none";

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-6"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget && !submitting) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="max-h-full w-full max-w-lg overflow-y-auto rounded-t-lg border border-rule bg-panel shadow-2xl sm:rounded-lg"
      >
        <div className="sprockets" aria-hidden="true" />
        <form onSubmit={handleSubmit} className="space-y-5 px-6 py-6">
          <h2 id={titleId} className="font-serif text-2xl font-semibold">
            New documentary project
          </h2>

          <div className="space-y-1.5">
            <label htmlFor="title" className="text-sm font-medium text-paper">
              Title
            </label>
            <input
              id="title"
              required
              autoFocus
              maxLength={200}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="The Lost Library of Alexandria"
              className={fieldClass}
            />
          </div>

          <div className="space-y-1.5">
            <label htmlFor="topic" className="text-sm font-medium text-paper">
              Topic
            </label>
            <textarea
              id="topic"
              required
              rows={4}
              maxLength={5000}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="What is the film about, and what angle should it take?"
              className={`${fieldClass} resize-y`}
            />
          </div>

          <div className="space-y-1.5">
            <label htmlFor="duration" className="text-sm font-medium text-paper">
              Target duration (seconds)
            </label>
            <input
              id="duration"
              type="number"
              inputMode="numeric"
              required
              min={MIN_SECONDS}
              max={MAX_SECONDS}
              step={1}
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              className={fieldClass}
            />
            <p className="text-sm text-dim">
              {durationValid
                ? `Runtime of ${formatDuration(seconds)} min`
                : `Enter ${MIN_SECONDS} to ${MAX_SECONDS} seconds`}
            </p>
          </div>

          {error && (
            <p
              role="alert"
              className="rounded-md border border-ember/50 bg-ember/10 px-3 py-2 text-sm text-[#f08a4b]"
            >
              {error}
            </p>
          )}

          <div className="flex justify-end gap-3 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="rounded-md px-4 py-2 text-sm font-medium text-dim hover:text-paper disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-md bg-lamp px-4 py-2 text-sm font-semibold text-ink hover:brightness-110 disabled:opacity-60"
            >
              {submitting ? "Creating project" : "Create project"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
