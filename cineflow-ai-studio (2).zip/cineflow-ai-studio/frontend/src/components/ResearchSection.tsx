"use client";

import { useState } from "react";
import ErrorBanner from "@/components/ErrorBanner";
import { generateResearch, type ResearchNote } from "@/lib/api";

function Paragraphs({ text }: { text: string }) {
  return (
    <div className="space-y-3">
      {text
        .split(/\n{2,}/)
        .filter((p) => p.trim())
        .map((p, i) => (
          <p key={i} className="leading-relaxed text-paper/90">
            {p}
          </p>
        ))}
    </div>
  );
}

export default function ResearchSection({
  projectId,
  research,
  onGenerated,
}: {
  projectId: string;
  research: ResearchNote | null;
  onGenerated: (note: ResearchNote) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleGenerate() {
    setBusy(true);
    setError(null);
    try {
      onGenerated(await generateResearch(projectId));
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Could not generate research. Check that the backend is running.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <section aria-labelledby="research-heading" className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 id="research-heading" className="font-serif text-2xl font-semibold">
            Research
          </h2>
          <p className="mt-1 text-sm text-dim">
            Written by Claude from its own knowledge, with no web search. Check
            facts before you publish.
          </p>
        </div>
        <button
          type="button"
          onClick={handleGenerate}
          disabled={busy}
          className="rounded-md bg-lamp px-5 py-2.5 text-sm font-semibold text-ink hover:brightness-110 disabled:opacity-60"
        >
          {busy
            ? "Generating research"
            : research
              ? "Regenerate Research"
              : "Generate Research"}
        </button>
      </div>

      {busy && (
        <p role="status" className="text-sm text-dim">
          Claude is researching this topic. This usually takes under a minute.
        </p>
      )}

      {error && <ErrorBanner message={error} onDismiss={() => setError(null)} />}

      {!research && !busy && (
        <div className="rounded-md border border-dashed border-rule px-6 py-12 text-center">
          <p className="font-serif text-xl">No research yet</p>
          <p className="mx-auto mt-2 max-w-md text-dim">
            Generate research notes to get a summary, key facts, historical
            context and visual ideas. The script is written from them.
          </p>
        </div>
      )}

      {research && (
        <div className="space-y-8 rounded-md border border-rule bg-panel p-6">
          <div>
            <h3 className="mb-2 font-serif text-lg font-semibold text-lamp">Summary</h3>
            <Paragraphs text={research.summary} />
          </div>

          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h3 className="mb-2 font-serif text-lg font-semibold text-lamp">Key facts</h3>
              <ul className="list-disc space-y-2 pl-5 marker:text-ember">
                {research.key_facts.map((fact, i) => (
                  <li key={i} className="leading-relaxed text-paper/90">
                    {fact}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="mb-2 font-serif text-lg font-semibold text-lamp">
                Visual angles
              </h3>
              <ul className="list-disc space-y-2 pl-5 marker:text-ember">
                {research.visual_angles.map((angle, i) => (
                  <li key={i} className="leading-relaxed text-paper/90">
                    {angle}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div>
            <h3 className="mb-2 font-serif text-lg font-semibold text-lamp">
              Historical context
            </h3>
            <Paragraphs text={research.historical_context} />
          </div>
        </div>
      )}
    </section>
  );
}
