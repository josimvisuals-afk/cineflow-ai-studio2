"use client";

import Link from "next/link";
import { useState } from "react";
import StatusBadge from "@/components/StatusBadge";
import { STATUS_ORDER, type Project } from "@/lib/api";
import { formatDate, formatDuration } from "@/lib/format";

// Stages after "draft": research -> script -> storyboard -> render -> done.
const PIPELINE = STATUS_ORDER.slice(1);

export default function ProjectCard({
  project,
  onDelete,
}: {
  project: Project;
  onDelete: (id: string) => Promise<void>;
}) {
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const stageIndex = PIPELINE.indexOf(project.status as (typeof PIPELINE)[number]);
  const filled = stageIndex + 1; // draft => 0

  async function handleDelete() {
    setBusy(true);
    setError(null);
    try {
      await onDelete(project.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete project.");
      setBusy(false);
    }
  }

  return (
    <article className="relative flex flex-col overflow-hidden rounded-md border border-rule bg-panel transition-colors hover:border-lamp/50">
      <div className="sprockets" aria-hidden="true" />

      <div className="flex flex-1 flex-col gap-3 px-5 py-4">
        <div className="flex items-start justify-between gap-3">
          <h2 className="font-serif text-xl font-semibold leading-snug text-paper">
            <Link
              href={`/projects/${project.id}`}
              className="after:absolute after:inset-0 after:content-[''] focus-visible:outline-none focus-visible:after:outline focus-visible:after:outline-2 focus-visible:after:outline-lamp"
            >
              {project.title}
            </Link>
          </h2>
          <StatusBadge status={project.status} />
        </div>

        <p className="line-clamp-3 text-sm leading-relaxed text-dim">
          {project.topic}
        </p>

        <div
          className="mt-1 flex gap-1"
          role="img"
          aria-label={`Pipeline progress: ${filled} of ${PIPELINE.length} stages, currently ${project.status}`}
        >
          {PIPELINE.map((stage, i) => (
            <span
              key={stage}
              className={`h-1 flex-1 rounded-full ${i < filled ? "bg-lamp" : "bg-rule"}`}
            />
          ))}
        </div>

        <div className="relative z-10 mt-auto flex items-center justify-between gap-3 pt-2 text-sm">
          <p className="text-dim">
            Target {formatDuration(project.target_duration_seconds)} min
            <span className="mx-2 text-rule" aria-hidden="true">
              |
            </span>
            {formatDate(project.created_at)}
          </p>

          {confirming ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDelete}
                disabled={busy}
                className="rounded px-2 py-1 font-medium text-[#f08a4b] hover:bg-ember/15 disabled:opacity-50"
              >
                {busy ? "Deleting" : "Delete project"}
              </button>
              <button
                type="button"
                onClick={() => setConfirming(false)}
                disabled={busy}
                className="rounded px-2 py-1 text-dim hover:text-paper disabled:opacity-50"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirming(true)}
              className="rounded px-2 py-1 text-dim hover:bg-ink hover:text-paper"
            >
              Delete
            </button>
          )}
        </div>

        {error && (
          <p role="alert" className="text-sm text-[#f08a4b]">
            {error}
          </p>
        )}
      </div>

      <div className="sprockets" aria-hidden="true" />
    </article>
  );
}
