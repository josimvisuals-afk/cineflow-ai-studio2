export default function ErrorBanner({
  message,
  onDismiss,
}: {
  message: string;
  onDismiss?: () => void;
}) {
  return (
    <div
      role="alert"
      className="flex items-start justify-between gap-4 rounded-md border border-ember/50 bg-ember/10 px-4 py-3 text-sm text-[#f08a4b]"
    >
      <p className="leading-relaxed">{message}</p>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          className="shrink-0 rounded px-2 py-0.5 font-medium hover:bg-ember/15"
        >
          Dismiss
        </button>
      )}
    </div>
  );
}
