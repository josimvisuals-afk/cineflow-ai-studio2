import Header from "@/components/Header";
import ProjectStudio from "@/components/ProjectStudio";

export default async function ProjectPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return (
    <>
      <Header />
      <main className="mx-auto w-full max-w-5xl px-5 pb-24 pt-8 sm:px-8">
        <ProjectStudio projectId={id} />
      </main>
    </>
  );
}
