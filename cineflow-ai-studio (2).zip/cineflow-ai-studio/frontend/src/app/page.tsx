import Dashboard from "@/components/Dashboard";
import Header from "@/components/Header";

export default function Home() {
  return (
    <>
      <Header />
      <main className="mx-auto w-full max-w-6xl px-5 pb-24 pt-10 sm:px-8">
        <Dashboard />
      </main>
    </>
  );
}
