# CineFlow AI Studio

Step 1: FastAPI + PostgreSQL backend and Next.js dashboard.
Step 2: Claude-powered research notes and narration scripts, saved to PostgreSQL, edited in `/projects/[id]`.

```
backend/    FastAPI, SQLAlchemy, PostgreSQL
frontend/   Next.js 15 (App Router), TypeScript, Tailwind CSS
remotion/   Placeholder for the Step 5 video renderer
```

## Run it

```bash
# 1. Infrastructure (PostgreSQL 16 on 5432, Redis 7 on 6379)
cp .env.example .env
docker compose up -d

# 2. Backend (http://localhost:8000, docs at /docs)
cd backend
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# 3. Frontend (http://localhost:3000), in a new terminal
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Quick API check: `curl http://localhost:8000/api/health`

Tables are created on backend startup (`Base.metadata.create_all`). Alembic is installed and ready to take over in a later step.

## Step 2: AI research and script engine

1. Put your key in `.env` (copy from `.env.example` if you have not): `ANTHROPIC_API_KEY=sk-ant-...`
   Optionally set `CLAUDE_MODEL` (default `claude-sonnet-4-5`).
2. Reinstall backend deps and restart (the backend reads `.env` only at startup):

```bash
cd backend && source .venv/bin/activate
pip install -r requirements.txt      # adds anthropic
uvicorn app.main:app --reload --port 8000
```

3. Restart the frontend:

```bash
cd frontend
npm install
npm run build        # confirm zero errors
npm run dev
```

New tables (`research_notes`, `scripts`) are created automatically on backend startup.

Endpoints: `POST|GET /api/projects/{id}/research`, `POST|GET|PATCH /api/projects/{id}/script`.
Error codes: 503 key missing/rejected/model not found/network, 429 rate limit, 502 other Anthropic errors or malformed output, 409 script requested before research.
